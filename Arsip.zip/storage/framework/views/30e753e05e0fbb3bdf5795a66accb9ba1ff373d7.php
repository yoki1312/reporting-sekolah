<?php $__env->startSection('page'); ?>

<main id="js-page-content" role="main" class="page-content">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='fal fa-info-circle'></i> SMART
        </h1>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Data Awal
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first()  ?>
                                        <td class="text-center"><?php echo e($da->jumlah_benar); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Rangking
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $totalData = array(); ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $rangking = rangkingSpk($l->id_kategori_ujian,$da->jumlah_benar);
                                            $totalData[$l->id_kategori_ujian][] = $rangking;
                                        ?>
                                           <td class="text-center"><?php echo e($rangking); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td>Total</td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php  
                                            $total  = array_sum( $totalData[$l->id_kategori_ujian] ) ;
                                        ?>
                                           <td class="text-center"><?php echo e($total); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Normalisasi
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $arrayNormalisasi = array(); ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $nilaiNormalisasi = ( rangkingSpk($l->id_kategori_ujian,$da->jumlah_benar) ) /  array_sum( $totalData[$l->id_kategori_ujian] );
                                            $arrayNormalisasi[$l->id_kategori_ujian][] = $nilaiNormalisasi;
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiNormalisasi); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                     
                        <div class="col-sm-12">
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>MAX</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                           $nilaiMax =  max($arrayNormalisasi[$l->id_kategori_ujian]);
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiMax); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <tr>
                                        <th>MIN</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                           $nilaiMin =  min($arrayNormalisasi[$l->id_kategori_ujian]);
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiMin); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead> 
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Utility
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </tr>
                                </thead>
                                <tbody> 
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td> 
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $nilaiNormalisasi = ( rangkingSpk($l->id_kategori_ujian,$da->jumlah_benar) ) /  array_sum( $totalData[$l->id_kategori_ujian] );
                                            $min = min($arrayNormalisasi[$l->id_kategori_ujian]);
                                            $max = max($arrayNormalisasi[$l->id_kategori_ujian]);
                                            if( ($nilaiNormalisasi-$min) > 0 && ($max-$min) > 0 ){
                                                $nilaiBagi =( (($nilaiNormalisasi-$min) / ($max-$min)) * 1 ) / 100 ; 
                                            }else{
                                                $nilaiBagi = 1;
                                            }
                                           
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiBagi); ?></td> 
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Nilai akhir
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        <th class="text-center">Jumlah</th> 
                                    </tr>
                                </thead>
                                <tbody> 
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td> 
                                        <?php $nilaiTOtal = 0; ?>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $nilaiNormalisasi = ( rangkingSpk($l->id_kategori_ujian,$da->jumlah_benar) ) /  array_sum( $totalData[$l->id_kategori_ujian] );
                                            $min = min($arrayNormalisasi[$l->id_kategori_ujian]);
                                            $max = max($arrayNormalisasi[$l->id_kategori_ujian]);
                                            if( ($nilaiNormalisasi-$min) > 0 && ($max-$min) > 0 ){
                                                $nilaiBagi =( (($nilaiNormalisasi-$min) / ($max-$min)) * 1 ) / 100 ; 
                                                $nilaiBagi = $nilaiBagi * bobotSpk($l->id_kategori_ujian);
                                            }else{
                                                $nilaiBagi = 1;
                                            }
                                            $nilaiTOtal += $nilaiBagi;
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiBagi); ?></td> 
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                           <td class="text-center table-danger"><?php echo e($nilaiTOtal); ?></td> 
                                        
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/Laravel Project/reporting-sekolah/resources/views/spk/smart.blade.php ENDPATH**/ ?>