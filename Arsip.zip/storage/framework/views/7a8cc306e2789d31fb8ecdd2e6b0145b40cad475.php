<?php $__env->startSection('page'); ?>

<main id="js-page-content" role="main" class="page-content">
    <div class="subheader">
        <h1 class="subheader-title">
            <i class='fal fa-info-circle'></i> SAW
        </h1>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Data Awal
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first()  ?>
                                        <td class="text-center"><?php echo e($da->jumlah_benar); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-12">
                            Rangking
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $totalData = array(); ?>
                                    <?php $arrayNormalisasi = array(); ?>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $rangking = rangkingSpk($l->id_kategori_ujian,$da->jumlah_benar);
                                            $totalData[$l->id_kategori_ujian][] = $rangking;
                                            $arrayNormalisasi[$l->id_kategori_ujian][] = $rangking;
                                        ?>
                                           <td class="text-center"><?php echo e($rangking); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td>Total</td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php  
                                            $total  = array_sum( $totalData[$l->id_kategori_ujian] ) ;
                                        ?>
                                           <td class="text-center"><?php echo e($total); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                   
                    <div class="row form-group">
                     
                        <div class="col-sm-12">
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>MAX</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                           $nilaiMax =  max($arrayNormalisasi[$l->id_kategori_ujian]);
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiMax); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <tr>
                                        <th>MIN</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                           $nilaiMin =  min($arrayNormalisasi[$l->id_kategori_ujian]);
                                        ?>
                                           <td class="text-center"><?php echo e($nilaiMin); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead> 
                            </table>
                        </div>
                    </div> 


                    <div class="row form-group">
                        <div class="col-sm-12">
                            Normalisasi
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="text-center"><?php echo e($k->nama_kategori_ujian); ?></th> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody> 
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $da = isset($da->jumlah_benar) ? $da->jumlah_benar : 0;
                                            $rangking = rangkingSpk($l->id_kategori_ujian,$da);
                                            $mx =  max($arrayNormalisasi[$l->id_kategori_ujian]);
                                            $mn =  min($arrayNormalisasi[$l->id_kategori_ujian]);

                                            $nilai1 = 0;
                                            if($l->id_kategori_ujian == 3){
                                                $nilai1 = $mn / $rangking;
                                            }else{
                                                $nilai1 = $rangking / $mx;
                                            }
                                        ?>
                                           <td class="text-center"><?php echo e($nilai1); ?></td> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-sm-4">
                            Hasil akhir
                            <table class="table table-sm table-secondary">
                                <thead>
                                    <tr>
                                        <th>Nama</th>
                                        <th class="text-center">Nilai</th>
                                    </tr>
                                </thead>
                                <tbody> 
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($k->nama_user); ?></td>
                                        <?php $nilais = 0; ?>
                                        <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                            $da = collect($nilai)->where('id_user', $k->id_user)->where('id_kategori_ujian', $l->id_kategori_ujian)->first();
                                            $da = isset($da->jumlah_benar) ? $da->jumlah_benar : 0;
                                            $rangking = rangkingSpk($l->id_kategori_ujian,$da);
                                            $mx =  max($arrayNormalisasi[$l->id_kategori_ujian]);
                                            $mn =  min($arrayNormalisasi[$l->id_kategori_ujian]);

                                            $nilai1 = 0;
                                            if($l->id_kategori_ujian == 3){
                                                $nilai1 = $mn / $rangking;
                                            }else{
                                                $nilai1 = $rangking / $mx;
                                            }
                                            $nilais += ( $nilai1 * bobotSpk($l->id_kategori_ujian) );
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td class="text-center"><?php echo e($nilais); ?></td> 
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/Laravel Project/reporting-sekolah/resources/views/spk/saw.blade.php ENDPATH**/ ?>