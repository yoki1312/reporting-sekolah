<?php
 
namespace App\Models;
 
use Illuminate\Database\Eloquent\Model;
 
class SekolahModels extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'm_sekolahan';
    protected $guard = '*';
}